#APP JSview (ROMA)

07/12/2015
El projecta ara es diu : PhoneGap Informàtica 2015 2016 4t ABC

Informàtica 4t ESO 2015 2016
INS Numància 
Santa Coloma de Gramenet

L'arxiu index inclou una estructura bàsica per crear una 
aplicació mòbil senzilla i dues opcions per crear transicions
mitjançant :

mobileUI

JSview [ aquesta és la activa, amb 3 pàgines (ABC) i un modal ]

Cal comentar els enllaços CSS i JS dels complements NO utilitzats

L'objectiu de l'APP és crear un aplicatiu agenda amb les activitats a realitzar durant el viatge a Roma

Cada dia serà una pàgina (viewA , viewB , .... )

Cada activitat serà un modal ( modalB_1, modalB_2 , ... )

--> Git : https://github.com/CeroyUno/JavaScriptView
--> Web : http://www.javascriptview.com/


