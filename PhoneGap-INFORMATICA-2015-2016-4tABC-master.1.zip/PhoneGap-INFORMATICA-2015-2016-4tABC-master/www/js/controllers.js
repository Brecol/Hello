/*
		CAL AFEGIR EL NOM DE LES VISTES DECLARADES A app.js
*/

$JSView.controller = {
	
	/* view pàgines */
    	inici: function(e){
		$JSView.dataView({},e)
	},
    	dimenge: function(e){
		$JSView.dataView({},e)	
	},
    	dilluns: function(e){
		$JSView.dataView({},e)
	},
    	dimarts: function(e){
		$JSView.dataView({},e)
	},
    	dimecres: function(e){
		$JSView.dataView({},e)
	},
    	dijous: function(e){
		$JSView.dataView({},e)
	},
    	divendres: function(e){
		$JSView.dataView({},e)
	},
	
	/* MODALS ROMA DIA 1 */
    	modal_info_aeroport: function(e){
		$JSView.dataView({},e)	
	},
	modal_info_coliseo: function(e){
		$JSView.dataView({},e)	
	},
    	modal_info_narvona: function(e){
		$JSView.dataView({},e)	
	},
    	modal_info_sanpietro: function(e){
		$JSView.dataView({},e)	
	},
    	
    	/* MAPES */
	mapes: function(e){
		$JSView.dataView({},e)	
	}
	
	
}
